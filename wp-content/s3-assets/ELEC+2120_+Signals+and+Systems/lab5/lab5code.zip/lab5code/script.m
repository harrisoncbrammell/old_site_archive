%Create Array t 
t = -10:0.1:10;

%Create Outputs y = u(t) and y = r(t) 
y_u = u(t,0);
y_r = r(t,0);

%% Step 3
figure(1);
subplot(2,2,1);
plot(t, u(t,0), 'LineWidth',2);
xlabel('Time (s)');
ylabel('Amplitude');
xlim([-10 10]);
ylim([-0.1 1.1]);
title('Plot of u(t)');
grid on;

subplot(2,2,2);
plot(t, r(t,0),'LineWidth',2 );
xlabel('Time (s)');
ylabel('Amplitude');
xlim([-10 10]);
ylim([0 10]);
title('Plot of r(t)');
grid on;

%% Step 4
figure(2);
subplot(2,2,1);
plot(t, pulse(t,1), 'LineWidth', 2);
xlim([-10 10]);
ylim([0 1]);
grid on;
xlabel('Time (s)');
ylabel('Amplitude');
title('Plot of P1(t)');

subplot(2,2,2);
plot(t, pulse(t,4),'LineWidth',2);
xlim([-10 10]);
ylim([0 1]);
grid on;
xlabel('Time (s)');
ylabel('Amplitude');
title('Plot of P4(t)');

%% Step 5a
figure(3); 
subplot(2,3,1);
plot(t, u(t,0), 'LineWidth',2);
xlabel('Time (s)');
ylabel('Amplitude');
xlim([-10 10]);
ylim([-0.1 1.1]);
title('Plot of u(t)');
grid on;

subplot(2,3,2);
plot(t, r(t,0),'LineWidth',2 );
xlabel('Time (s)');
ylabel('Amplitude');
xlim([-10 10]);
ylim([0 10]);
title('Plot of r(t)');
grid on;

subplot(2,3,3);
plot(t, pulse(t,1), 'LineWidth', 2);
xlim([-10 10]);
ylim([-0.1 1.1]);
grid on;
xlabel('Time (s)');
ylabel('Amplitude');
title('Plot of P1(t)');

%% Step 5b
figure(4);
x1 = (r(t,0)-r(t,2))+(3*u(t,2))+(0.4*pulse(t,9));
subplot(2,2,1);
plot(t, x1,'LineWidth',2,'LineStyle','--');
xlabel('Time (s)');
ylabel('Amplitude');
title('Plot of x1(t)');
xlim([-10 10]);
ylim([0 6]);
grid on;

subplot(2,2,2);
x2 = r(t,0) - 2*r(t,2) + 4*u(t,2) + r(t,4) - 4*u(t,4);
plot(t, x2,'LineWidth',2,'LineStyle','-.');
xlabel('Time (s)');
ylabel('Amplitude');
title('Plot of x2(t)');
xlim([-10 10]);
ylim([0 7]);
grid on;




