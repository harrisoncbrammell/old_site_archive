function y = pulse(t, tau)
    % Pulse Function
    % y = pulse(t, tau) implements a pulse of width tau centered at t = 0
    y = u(t,-tau/2) - u(t,tau/2);
end